package practice;

class Node2 {
    int data;
    Node2 prev;
    Node2 next;

    public Node2(int data) {
        this.data = data;
        this.prev = null;
        this.next = null;
    }
}

class DoublyLinkedList {
    Node2 head;

    public DoublyLinkedList() {
        this.head = null;
    }

    public void insert(int data) {
        Node2 newNode = new Node2(data);

        if (head == null) {
            head = newNode;
        } else {
            Node2 current = head;
            while (current.next != null) {
                current = current.next;
            }
            current.next = newNode;
            newNode.prev = current;
        }
    }

    public void traverseForward() {
        if (head == null) {
            System.out.println("List is empty");
            return;
        }

        Node2 current = head;
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.next;
        }
        System.out.println();
    }

    public void traverseBackward() {
        if (head == null) {
            System.out.println("List is empty");
            return;
        }

        Node2 current = head;
        while (current.next != null) {
            current = current.next;
        }

        while (current != null) {
            System.out.print(current.data + " ");
            current = current.prev;
        }
        System.out.println();
    }
}
public class DoublyLinkedListTraversal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 DoublyLinkedList list = new DoublyLinkedList();
	        list.insert(10);
	        list.insert(20);
	        list.insert(30);
	        list.insert(40);
	        list.insert(50);

	        System.out.println("Forward traversal:");
	        list.traverseForward();

	        System.out.println("Backward traversal:");
	        list.traverseBackward();
	}

}
