package practice;

public class LinearSearchDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Iterate through a collection one element at a time.....O(n)
		int[] array= {1,2,3,4,5,6,7,8};
		int index=LinearSearch(array,5);
		if(index!=1)
		{
			System.out.println("Element found at index"+index);
		}
		else
		{
			System.out.println("Element not found");
		}
	}

	private static int LinearSearch(int[] array, int value) {
		// TODO Auto-generated method stub
		for(int i=0;i<array.length;i++)
		{
			if(array[i]==value)
			{
				return i;
			}
		}
		return -1;
	}

}
