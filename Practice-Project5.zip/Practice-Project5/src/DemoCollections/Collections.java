package DemoCollections;
import java.util.*;
public class Collections {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

//creating array list
System.out.println("-----ArrayList-----");
List<Integer> arrayList=new ArrayList<Integer>(5);   
for(int i=1;i<+5;i++)
{
arrayList.add(i);//
}
System.out.println(arrayList);
arrayList.remove(2);
System.out.println(arrayList);
for(int i=0;i<arrayList.size();i++)
System.out.print(arrayList.get(i)+ " ");

//creating vector
System.out.println("\n");
System.out.println("-----Vector-----");
Vector<Integer> vec = new Vector<Integer>();
vec.addElement(15); 
vec.addElement(30); 
System.out.println(vec);
vec.removeElement(15);
System.out.println(vec);

//creating linked list
System.out.println("\n");
System.out.println("-----LinkedList-----");
LinkedList<String> list=new LinkedList<String>();  
list.add("Alex");  
list.add("John");  
list.addLast("Chinnu");
list.addFirst("Jyoshna");
list.add(2,"Geetha");
System.out.println(list);  
list.remove(1);
System.out.println(list);							      

//creating hashset
System.out.println("\n");
System.out.println("-----HashSet-----");
HashSet<String> set=new HashSet<String>();  
set.add("A");  
set.add("B");  

//First c will get executed
set.add("C");
set.add("C");
System.out.println(set);
set.remove("C");
System.out.println("Set After removing C: " +set);

//creating linked hash set
System.out.println("\n");
System.out.println("-----LinkedHashSet-----");
LinkedHashSet<Integer> set2=new LinkedHashSet<Integer>();  
set2.add(11);  
set2.add(13);  
set2.add(12);
set2.add(14);	       
System.out.println(set2);					   
//Treeset Example
System.out.println("\n");
System.out.println("-----TreeSet-----");
 TreeSet<String> tree=new TreeSet<String>();
tree.add("C");
tree.add("B");
tree.add("A");
System.out.println(tree);

//Queue
System.out.println("\n");
 System.out.println("-----Queue-----");
 Queue<String> q=new PriorityQueue<String>();
q.add("a");
q.add("b");
q.add("c");
System.out.println(q);
q.remove("c");
System.out.println(q);
q.peek();
System.out.println(q);
q.poll();
System.out.println(q);								      

//stack
System.out.println("\n");
System.out.println("-----Stack-----");
Stack<String> s=new Stack<String>();
s.push("OS");
s.push("Andriod");
s.push("Harddisk");
System.out.println(s);
s.pop();
System.out.println(s);
} 
}


