package implicitandexplicit;

public class TypeCasting {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Implicit Casting or Widening
		System.out.println("Implicit Casting");
		int a=10;
		float b=a;
		System.out.println("The value of b is:"+b);
		long c=a;
		System.out.println("The value of c is:"+c);
		double d=a;
		System.out.println("The value of d is:"+d);
		char v='E';
		int e=v;
		System.out.println("The value of e is:"+e);
		//Explicit casting or Narrowing
		System.out.println("Explicit Casting");
		int x=70;
		char y=(char)x;
		System.out.println("The value of x is:"+x);
		System.out.println("The value of y is:"+y);
		double p=70;
		int q=(int)p;
		System.out.println("The value of p is:"+p);
		System.out.println("The value of q is:"+q);
		
		

	}

}