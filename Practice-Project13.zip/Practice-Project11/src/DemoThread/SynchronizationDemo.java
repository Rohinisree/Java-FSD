package DemoThread;

public class SynchronizationDemo implements Runnable {
	int count;
	public synchronized void run()
	{
		for(int i=1;i<=1000;i++)
		{
			count++;
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SynchronizationDemo sd=new SynchronizationDemo();
		Thread t1=new Thread(sd);
		Thread t2=new Thread(sd);
		t1.start();
		try {
			t1.join();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		t2.start();
		try {
			t2.join();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Count is:"+sd.count);
		
		

	}
	}
