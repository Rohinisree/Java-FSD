package practice;


public class BubbleSortDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Bubble sort arranges the input in ascending or descending order,it compares by 2 adjacent pairs of elements in an array
		//its takes n-1 comparisionsn=no.of elements)
		// Space pComplexity:O(1)
		//Ascending Order:
		//For descending odrder is :arr[j-1]<arr[j]
		int arr[]= {11,6,5,2,1};
		int length=arr.length;
		for(int i=0;i<length;i++)
		{
			for(int j=1;j<length-i;j++)
			{
				if(arr[j-1]>arr[j])
				{
					int temp=arr[j];
					arr[j]=arr[j-1];
					arr[j-1]=temp;
				}
			}
		}
		System.out.print("Sorted Array :");
		for(int i=0;i<length;i++)
			System.out.print(arr[i]+" ");
		

	}

}
