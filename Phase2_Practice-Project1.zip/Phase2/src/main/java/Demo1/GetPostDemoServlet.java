package Demo1;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;


public class GetPostDemoServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	
  	  PrintWriter pw=response.getWriter();
  	  
  	  pw.write("Recieved a GET request!."
  			  +"Notice That Whatever data you submitted  in the form fields,WILL APPEAR in the browsers address bar");
  	  
  	  pw.close();	
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 PrintWriter pw=response.getWriter();
	  	  
	  	  pw.write("Recieved a POST request!");
	  	  
	  	  pw.close();
	}

}
