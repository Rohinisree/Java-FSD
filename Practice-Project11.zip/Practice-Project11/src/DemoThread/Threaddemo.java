package DemoThread;

public class Threaddemo extends Thread {
    public void run() {
        System.out.println("Hello MyThread!");
    }

    public static void main(String[] args) {
        Threaddemo thread = new Threaddemo();
        Thread t=new Thread(thread);
        t.start(); // This will call the run() method
    }
}
