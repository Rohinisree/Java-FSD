package DemoString;

public class string {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String var1="Rohini";
		String var2="Sre";
		System.out.println(var1.charAt(4));
		System.out.println(var1.codePointAt(4));
		System.out.println(var1.codePointBefore(4));
		System.out.println(var1.codePointCount(0,4));
		System.out.println(var1.compareTo(var2));
		System.out.println(var1.concat(var2));
		System.out.println(var1.compareToIgnoreCase(var2));
		System.out.println(var1.contains(var2));
		System.out.println(var1.endsWith("i"));
		System.out.println(var1.equals(var2));
		System.out.println(var1.equalsIgnoreCase(var2));
		System.out.println(var1.hashCode());
		System.out.println(var1.indexOf("n"));
		System.out.println(var1.isEmpty());
		System.out.println(var1.length());
		System.out.println(var1.replace("e","i"));
		System.out.println(var1.startsWith("R"));
		System.out.println(var1.toUpperCase());
		System.out.println(var1.toLowerCase());
		System.out.println(var1.trim());
		
		 // conversion from String object to StringBuffer 
        StringBuffer sbr = new StringBuffer(var1); 
        sbr.reverse(); 
        System.out.println("String to StringBuffer");
        System.out.println(sbr); 
          
        // conversion from String object to StringBuilder 
        StringBuilder sbl = new StringBuilder(var1); 
        sbl.append("world"); 
        System.out.println("String to StringBuilder");
        System.out.println(sbl);   
	}

}

