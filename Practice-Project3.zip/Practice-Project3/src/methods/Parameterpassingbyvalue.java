package methods;


public class Parameterpassingbyvalue {

		public static void main(String[] args) {
			// TODO Auto-generated method stub
	          int x=1;
	          increment(x);
	          System.out.println(x);
		}
	   public static void increment(int x)
	   {
		   x++;
		   System.out.println(x);
	   }
	}
