package DemoMaps;
import java.util.*;
public class Maps {
	public static void main(String[] args) {
			// TODO Auto-generated method stub
			System.out.println("HashMap");
			Map<String,Integer> mp=new HashMap<>();
			mp.put("a", 10);
			mp.put("b", 20);
			mp.put("d", 40);
			mp.put("c", 30);
			System.out.println(mp);
			
			}

	}


