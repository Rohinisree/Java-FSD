package DemoAccessModifiers;

public class Car extends Student {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student s=new Student();
		System.out.println(s.rollNo);
		s.printRollNumber();
		
	}
    public void abc()
    {
    	System.out.println(rollNo);
    }
}