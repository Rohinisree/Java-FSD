package DemoThread;

public class TryCatchDemo {
    public static void main(String[] args) {
        try {
            // This will throw a NumberFormatException
        	  int x = Integer.parseInt("Hiiiii...");
        } 
        catch (NumberFormatException e) 
        {
            System.out.println("Caught NumberFormatException: " + e.getMessage());
        }

        try 
        {
            int[] arr = new int[3];
            arr[3] = 10; // This will throw an ArrayIndexOutOfBoundsException
        } 
        catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("Caught ArrayIndexOutOfBoundsException: " + e.getMessage());
        }

        System.out.println("Program continues to run...");
    }
}
