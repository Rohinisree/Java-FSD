package practice;

import java.util.Arrays;
import java.util.Scanner;
public class BinarySearchDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a[]= {15,24,38,7,2,89,56};//unsorted 
		Arrays.sort(a);
		System.out.println("he sorted array is ");
		for(int b:a) {
			System.out.print(b+",");
		}
		System.out.println();
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the element to search");
		int key=sc.nextInt();

		int low=0;
		int high=a.length-1;
		int mid=0;
		while(low<=high) {
			
			mid=(low+high)/2;
		
			if(a[mid]==key) {
				System.out.println("element is found at the location "+ (mid+1));
				break;
			}
			else if(a[mid]<key) {
				low=mid+1;
				
			}
			else {
				high=mid-1;
			}
			
		}
		
		
	}
	}

