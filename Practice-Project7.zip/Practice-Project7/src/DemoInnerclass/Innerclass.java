package DemoInnerclass;

class Demo
{
	public void show()
	{ 
		System.out.println("In Show");
	}
	//Only Inner Class Make it static
	static class B
	
	{
		public void config()
		{
			System.out.println("In Config");
		}
	}
}
public class Innerclass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Demo obj=new Demo();
		obj.show();
		
		Demo.B obj1=new Demo.B();
		obj1.config();
	}}