package DemoThread;

import java.util.Scanner;
public class CustomDemo extends Exception{
	public CustomDemo(String str)
{
	super(str);
}

	public static void main(String[] args) throws CustomDemo{
		// TODO Auto-generated method stub
		System.out.println("Enter the age ");
		try
		{
			Scanner sc=new Scanner(System.in);
			int age=sc.nextInt();
			if(age<18)
			{
				throw new CustomDemo("You are not eligible to vote");
			}
			else
			{
				System.out.println("You are eligible to vote");
			}
		}
			catch(CustomDemo cd)
			{
				cd.printStackTrace();
			}
		}
}
