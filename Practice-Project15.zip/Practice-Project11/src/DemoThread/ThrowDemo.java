package DemoThread;

public class ThrowDemo {

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		int age=50;
		try 
		{
			validateAge(age);
			System.out.println("You are eligible to vote");
		}
		catch(IllegalArgumentException ex)
		{
			System.out.println("Invalid age:"+ex.getMessage());
		}
	}
	public static void validateAge(int age)
	{
		if(age<18)
		{
			throw new IllegalArgumentException("Age should be greater than or equal to 18");

		}
		
	}}
