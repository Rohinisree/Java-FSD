package DemoThread;

public class FinallyDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try{    
			   //below code do not throw any exception  
			   int data=8/4;    
			   System.out.println(data);    
			}      
	    catch(NullPointerException e)
		{  
	    	//catch won't be executed
	    	System.out.println(e);  
		}    
		finally 
		{  
			//executed regardless of exception occurred or not
			System.out.println("finally block will always get executed");  
		}    
			     

	}

}
