package constructors;

public class Constructor {
	

	public class classA {

		private int x;
		int y;

		protected int z = 10;

		public int p = 100;
		
		//Default Constructor
		public classA() {		
			this.x=100;
			this.y=100;		
		}
		//parameterized constructor
		public classA(int x, int y) {		
			this.x=x;
			this.y=y;		
		}
		//constructor with no parameter
		public int getValueOfx() {

			 return this.x;

		}
		

		public void method1A() {

			System.out.println("value of x = " + x);

		}

		public int method2A(int a) {

			return a*a;

		}
		
		// An overloaded method of above method
		public int method2A(int a, int b) {

			return a*b;

		}

	}

}
