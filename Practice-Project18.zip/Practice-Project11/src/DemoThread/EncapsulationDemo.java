package DemoThread;

class BankAccount {
    private String accountNumber;
    private double balance;
    
    public BankAccount(String accountNumber, double balance) {
        this.accountNumber = accountNumber;
        this.balance = balance;
    }
    
    public String getAccountNumber() {
        return accountNumber;
    }
    
    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }
    
    public double getBalance() {
        return balance;
    }
    
    public void setBalance(double balance) {
        this.balance = balance;
    }
    
    public void deposit(double amount) {
        balance += amount;
    }
    
    public void withdraw(double amount) {
        if (amount <= balance) {
            balance -= amount;
        } else {
            System.out.println("Insufficient funds.");
        }
    }}
public class EncapsulationDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BankAccount myAccount = new BankAccount("1234567890", 1000);
        
        System.out.println("Account number: " + myAccount.getAccountNumber());
        System.out.println("Balance: $" + myAccount.getBalance());
        
        myAccount.deposit(500);
        System.out.println("Balance after deposit: $" + myAccount.getBalance());
        
        myAccount.withdraw(200);
        System.out.println("Balance after withdrawal: $" + myAccount.getBalance());

	}

}
