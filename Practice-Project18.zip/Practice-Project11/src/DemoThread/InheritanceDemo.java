package DemoThread;

class Vehicle {
    private int numWheels;
    private String color;
    
    public Vehicle(int numWheels, String color) {
        this.numWheels = numWheels;
        this.color = color;
    }
    
    public void drive() {
        System.out.println("Driving...");
    }
    
    public int getNumWheels() {
        return numWheels;
    }
    
    public void setNumWheels(int numWheels) {
        this.numWheels = numWheels;
    }
    
    public String getColor() {
        return color;
    }
    
    public void setColor(String color) {
        this.color = color;
    }
}

class Car1 extends Vehicle {
    private String make;
    private String model;
    
    public Car1(int numWheels, String color, String make, String model) {
        super(numWheels, color);
        this.make = make;
        this.model = model;
    }
    
    public void honk() {
        System.out.println("Honk honk!");
    }
    
    public String getMake() {
        return make;
    }
    
    public void setMake(String make) {
        this.make = make;
    }
    
    public String getModel() {
        return model;
    }
    
    public void setModel(String model) {
        this.model = model;
    }}
public class InheritanceDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Car1 myCar = new Car1(4, "Red", "Toyota", "Camry");
        
        System.out.println("My car is a " + myCar.getColor() + " " + myCar.getMake() + " " + myCar.getModel() + " with " + myCar.getNumWheels() + " wheels.");
        
        myCar.drive();
        myCar.honk();

	}

}
