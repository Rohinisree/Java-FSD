package DemoThread;

class Animal1 {
    public void makeSound() {
        System.out.println("Some generic sound");
    }
}

class Dog1 extends Animal1 {
    public void makeSound() {
        System.out.println("Bark!");
    }
}

class Cat1 extends Animal1 {
    public void makeSound() {
        System.out.println("Meow!");
    }
}

public class PolymorphisimDemo {
    public static void main(String[] args) {
		// TODO Auto-generated method stub
		Animal1 myAnimal1 = new Dog1();
        Animal1 myAnimal2 = new Cat1();
        
        myAnimal1.makeSound();
        myAnimal2.makeSound();
	}}

